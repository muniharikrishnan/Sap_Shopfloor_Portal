sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageToast"
], function (Controller, JSONModel, Filter, FilterOperator, MessageToast) {
  "use strict";

  return Controller.extend("SHOPFLOOR.controller.PlannedOrders", {
    onInit: function () {
      this._loadPlannedOrders();
    },

    _loadPlannedOrders: function (aFilters = [new Filter("Plwrk", FilterOperator.EQ, "0001")]) {
      const oModel = this.getOwnerComponent().getModel();
      const oTable = this.getView().byId("plannedOrdersTable");

      oModel.read("/PPPLANNEDORDERSet", {
        filters: aFilters,
        success: function (oData) {
          const aFormattedResults = oData.results.map((item) => ({
            ...item,
            Psttr: item.Psttr ? new Date(item.Psttr) : null,
            Pedtr: item.Pedtr ? new Date(item.Pedtr) : null,
            Pertr: item.Pertr ? new Date(item.Pertr) : null
          }));
          oTable.setModel(new JSONModel(aFormattedResults), "PlannedOrders");
        },
        error: function () {
          MessageToast.show("Failed to load planned orders.");
        }
      });
    },

    formatDate: function (oDate) {
      if (!oDate) return "01-Jan-2024";
      const options = { year: "numeric", month: "short", day: "numeric" };
      return new Intl.DateTimeFormat("en-US", options).format(oDate);
    },

    onDateFilter: function () {
      const oStart = this.getView().byId("startDate").getDateValue();
      const oEnd = this.getView().byId("endDate").getDateValue();

      if (!oStart || !oEnd) {
        MessageToast.show("Please select both Start and End Dates.");
        return;
      }

      if (oEnd < oStart) {
        MessageToast.show("End Date cannot be before Start Date.");
        return;
      }

      const formatDate = (d) => d.toISOString().split("T")[0] + "T00:00:00";
      const aFilters = [
        new Filter("Plwrk", FilterOperator.EQ, "0001"),
        new Filter("Psttr", FilterOperator.GE, formatDate(oStart)),
        new Filter("Pedtr", FilterOperator.LE, formatDate(oEnd))
      ];

      this._loadPlannedOrders(aFilters);
    },

    onClearFilter: function () {
      this.byId("startDate").setValue("");
      this.byId("endDate").setValue("");
      this._loadPlannedOrders();
    },

    onNavBack: function () {
      this.getOwnerComponent().getRouter().navTo("Dashboard");
    }
  });
});
