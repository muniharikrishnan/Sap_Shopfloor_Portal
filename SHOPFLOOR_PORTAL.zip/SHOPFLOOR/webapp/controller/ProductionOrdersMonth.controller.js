sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, Filter, FilterOperator, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("SHOPFLOOR.controller.ProductionOrdersMonth", {
        onInit: function () {
            // Check if user is logged in
            var sPlant = localStorage.getItem("SHOPFLOOR_PLANT");
            
            if (!sPlant) {
                // User not logged in, redirect to login
                this.getOwnerComponent().getRouter().navTo("Login");
                return;
            }
            
            // Initialize view model
            this._oViewModel = new JSONModel({
                busy: false,
                data: []
            });
            this.getView().setModel(this._oViewModel, "viewModel");
            
            this._loadData();
        },

        onAfterRendering: function () {
            // Additional setup after rendering
        },

        _loadData: function () {
            var that = this;
            var oViewModel = this.getView().getModel("viewModel");
            
            oViewModel.setProperty("/busy", true);
            
            // Get plant from localStorage
            var sPlant = localStorage.getItem("SHOPFLOOR_PLANT");
            
            // OData call to fetch month-wise production orders
            var sUrl = "/sap/opu/odata/SAP/Z48_PP_PORTAL2_SRV/pp_production_monthSet?$filter=Werks eq '" + sPlant + "'&$format=json";
            
            jQuery.ajax({
                url: sUrl,
                type: "GET",
                dataType: "json",
                success: function (oData) {
                    if (oData && oData.d && oData.d.results) {
                        oViewModel.setProperty("/data", oData.d.results);
                        MessageToast.show("Data loaded successfully: " + oData.d.results.length + " records");
                    } else {
                        oViewModel.setProperty("/data", []);
                        MessageToast.show("No data found");
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error loading data:", error);
                    MessageBox.error("Failed to load data. Please check your connection and try again.");
                    oViewModel.setProperty("/data", []);
                },
                complete: function () {
                    oViewModel.setProperty("/busy", false);
                }
            });
        },

        onSearch: function (oEvent) {
            var sQuery = oEvent.getParameter("query");
            this._applyFilters(sQuery);
        },

        onSearchLiveChange: function (oEvent) {
            var sQuery = oEvent.getParameter("newValue");
            this._applyFilters(sQuery);
        },

        onDateRangeChange: function () {
            this._applyDateRangeFilter();
        },

        onDocumentNumberChange: function (oEvent) {
            var sDocumentNumber = oEvent.getParameter("newValue");
            this._applyDocumentNumberFilter(sDocumentNumber);
        },

        onClearFilters: function () {
            // Clear all filters
            this.byId("searchField").setValue("");
            this.byId("fromDatePicker").setValue("");
            this.byId("toDatePicker").setValue("");
            this.byId("documentNumberInput").setValue("");
            
            // Reset data to original by reloading
            this._loadData();
            
            MessageToast.show("All filters cleared");
        },

        onRefreshData: function () {
            this._loadData();
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("Dashboard");
        },

        _applyFilters: function (sQuery) {
            if (!sQuery) {
                this._resetToOriginalData();
                return;
            }

            var oViewModel = this.getView().getModel("viewModel");
            var oCurrentData = oViewModel.getProperty("/data");
            
            if (!oCurrentData || oCurrentData.length === 0) {
                return;
            }

            var aFilteredData = oCurrentData.filter(function (oItem) {
                // Search by month-year (convert MM-YYYY to Month YYYY for comparison)
                var sMonthYear = oItem.Monthyr;
                if (sMonthYear) {
                    var aParts = sMonthYear.split("-");
                    if (aParts.length === 2) {
                        var iMonth = parseInt(aParts[0]) - 1;
                        var iYear = parseInt(aParts[1]);
                        var oDate = new Date(iYear, iMonth, 1);
                        var sMonthName = oDate.toLocaleDateString("en-US", { month: "long" });
                        var sFormattedMonthYear = sMonthName + " " + iYear;
                        
                        if (sFormattedMonthYear.toLowerCase().includes(sQuery.toLowerCase())) {
                            return true;
                        }
                    }
                }
                
                // Search by other fields
                return oItem.Aufnr && oItem.Aufnr.toString().toLowerCase().includes(sQuery.toLowerCase()) ||
                       oItem.Ktext && oItem.Ktext.toString().toLowerCase().includes(sQuery.toLowerCase()) ||
                       oItem.Ernam && oItem.Ernam.toString().toLowerCase().includes(sQuery.toLowerCase());
            });

            oViewModel.setProperty("/data", aFilteredData);
        },

        _applyDateRangeFilter: function () {
            var oFromDate = this.byId("fromDatePicker").getDateValue();
            var oToDate = this.byId("toDatePicker").getDateValue();
            
            if (!oFromDate && !oToDate) {
                this._resetToOriginalData();
                return;
            }

            var oViewModel = this.getView().getModel("viewModel");
            var oCurrentData = oViewModel.getProperty("/data");
            
            if (!oCurrentData || oCurrentData.length === 0) {
                return;
            }

            var aFilteredData = oCurrentData.filter(function (oItem) {
                var bInclude = true;
                
                if (oFromDate && oItem.Gstrp) {
                    var sMatch = oItem.Gstrp.match(/\/Date\((\d+)\)\//);
                    if (sMatch && sMatch[1]) {
                        var oItemDate = new Date(parseInt(sMatch[1]));
                        if (oItemDate < oFromDate) {
                            bInclude = false;
                        }
                    }
                }
                
                if (oToDate && oItem.Gltrp) {
                    var sMatch = oItem.Gltrp.match(/\/Date\((\d+)\)\//);
                    if (sMatch && sMatch[1]) {
                        var oItemDate = new Date(parseInt(sMatch[1]));
                        if (oItemDate > oToDate) {
                            bInclude = false;
                        }
                    }
                }
                
                return bInclude;
            });

            oViewModel.setProperty("/data", aFilteredData);
        },

        _applyDocumentNumberFilter: function (sDocumentNumber) {
            if (!sDocumentNumber) {
                this._resetToOriginalData();
                return;
            }

            var oViewModel = this.getView().getModel("viewModel");
            var oCurrentData = oViewModel.getProperty("/data");
            
            if (!oCurrentData || oCurrentData.length === 0) {
                return;
            }

            var aFilteredData = oCurrentData.filter(function (oItem) {
                return oItem.Aufnr && oItem.Aufnr.toString().toLowerCase().includes(sDocumentNumber.toLowerCase());
            });

            oViewModel.setProperty("/data", aFilteredData);
        },

        _resetToOriginalData: function () {
            // Reset to original data by reloading
            this._loadData();
        }
    });
});
