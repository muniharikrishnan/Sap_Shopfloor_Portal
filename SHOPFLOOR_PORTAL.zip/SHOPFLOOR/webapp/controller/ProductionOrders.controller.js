sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageToast"
], function (Controller, Filter, FilterOperator, MessageToast) {
  "use strict";

  return Controller.extend("SHOPFLOOR.controller.ProductionOrders", {
    onInit: function () {
      const oModel = this.getOwnerComponent().getModel();
      this.getView().setModel(oModel);
    },

    onDateFilter: function () {
      const oStartDate = this.byId("startDate").getDateValue();
      const oEndDate = this.byId("endDate").getDateValue();

      if (!oStartDate || !oEndDate) {
        MessageToast.show("Please select both Start and End Dates.");
        return;
      }

      if (oEndDate < oStartDate) {
        MessageToast.show("End Date cannot be before Start Date.");
        return;
      }

      const sStart = oStartDate.toISOString().split("T")[0] + "T00:00:00";
      const sEnd = oEndDate.toISOString().split("T")[0] + "T00:00:00";

      const aFilters = [
        new Filter("Werks", FilterOperator.EQ, "0001"),
        new Filter("Gstrp", FilterOperator.GE, sStart),
        new Filter("Gltrp", FilterOperator.LE, sEnd)
      ];

      const oBinding = this.byId("productionTable").getBinding("items");
      if (oBinding) oBinding.filter(aFilters);
    },

    clearFilters: function () {
      this.byId("startDate").setValue("");
      this.byId("endDate").setValue("");
      this.byId("productionTable").getBinding("items").filter([]);
    },

    onBackToDashboard: function () {
      this.getOwnerComponent().getRouter().navTo("Dashboard");
    },

    formatDate: function (oDate) {
      if (!oDate) return "01-Jan-2024";
      return new Intl.DateTimeFormat("en-US", { year: "numeric", month: "short", day: "numeric" }).format(new Date(oDate));
    },

    formatValue: function (sValue) {
      return sValue || "N/A";
    }
  });
});
